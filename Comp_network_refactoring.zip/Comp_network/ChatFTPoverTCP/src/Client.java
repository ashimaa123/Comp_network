/*
 * Filename     Client.java
 * Date         5/1/2020
 * Author       Ashima Soni, Mira Jambusaria
 * Email        ashima.soni@utdallas.edu mmj170530@utdallas.edu
 * Course       CE 4390.502 Spring 2020
 * Version      1.0
 * Copyright    2020, All Rights Reserved
 *
 * Description
 *
 * This is the file that creates the Client side connection
 *
 */
import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/*
 * Class Client
 * Description:         Handles all the client  side functions
 */
public class Client
{
    /* hardcoded port number */
    int PORT = 3100;

    /* hardcoded server IP*/
    String serverIP = "127.0.0.1";

    /* create the socket */
    Socket socket;

    //DECLARING CLIENTSIDE CONSTANTS
    /* read input from the keyboard */
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

    /* receiving from server */
    InputStream inputStream;
    /* read input from the server */
    BufferedReader reader;

    /* create a stream to send output to the server */
    OutputStream outputStream;

    /* Prints formatted representations of objects to a text-output stream - useful for displaying messages */
    PrintWriter printWriter;

    ExecutorService executorService = Executors.newFixedThreadPool(2);

    private String receiveMessage = "", sendMessage = "", filename = "";

    /*
     * Constructor for the Client Class
     */
    public Client() throws IOException {
        socket = new Socket(serverIP, PORT);
        inputStream = socket.getInputStream();
        outputStream = socket.getOutputStream();
        reader = new BufferedReader(new InputStreamReader(inputStream));
        printWriter = new PrintWriter(outputStream, true);

    }



    void send(){
        while(!(sendMessage.equals("End") || sendMessage.equals("end"))) {
            try {
                sendMessage = input.readLine();  // keyboard reading
                if (sendMessage.startsWith("requestFile")) {
                    String[] command = sendMessage.split(" ");
                    if (command.length < 2) {
                        System.out.println("NO FILENAME provided. Try again.");
                        continue;
                    } else {
                        filename = sendMessage.split(" ")[1];
                    }
                }

                printWriter.println(sendMessage);       // sending to server
                printWriter.flush();                    // flush the data
                System.out.println("MESSAGE SUCCESSFULLY SENT");
                if (sendMessage.equals("End") || sendMessage.equals("end")) {
                    outputStream.close();
                    inputStream.close();
                    input.close();
                    socket.close();
                    executorService.shutdownNow();
                    System.exit(0);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    void receive(){
        new FTP();
        while(!(sendMessage.equals("End") || sendMessage.equals("end"))) {
            try {
                if ((receiveMessage = receiveRead.readLine()) != null) //receive from server
                {
                    if (receiveMessage.equals("End") || receiveMessage.equals("end")) {
                        System.out.println(receiveMessage);
                        outputStream.close();
                        inputStream.close();
                        input.close();
                        socket.close();
                        System.out.println("Server closed connection. Press enter to stop the server.");
                        executorService.shutdownNow();
                        System.exit(0);
                    }
                    if (receiveMessage.equals("receiveFile")) {
                        System.out.println("Receiving File...");
                        FTP.receive(filename, socket);
                    }
                    else {
                        System.out.println("THIS IS CHAT DATA");
                        System.out.println(receiveMessage); // displaying at DOS prompt

                    }
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public void execute(){

        // method reference introduced in Java 8
        executorService.submit(this::send);
        executorService.submit(this::receive);

        // close executorService
        executorService.shutdown();
    }

    public static void main(String[] args) throws Exception
    {
        System.out.println("CONNECT ACKNOWLEDGMENT");

        System.out.println("Ready. To send a message, type the message and press 'Enter' to send. To request a file, type 'requestFile' and the file name. \n\n");

        new Client().execute();
    }
}